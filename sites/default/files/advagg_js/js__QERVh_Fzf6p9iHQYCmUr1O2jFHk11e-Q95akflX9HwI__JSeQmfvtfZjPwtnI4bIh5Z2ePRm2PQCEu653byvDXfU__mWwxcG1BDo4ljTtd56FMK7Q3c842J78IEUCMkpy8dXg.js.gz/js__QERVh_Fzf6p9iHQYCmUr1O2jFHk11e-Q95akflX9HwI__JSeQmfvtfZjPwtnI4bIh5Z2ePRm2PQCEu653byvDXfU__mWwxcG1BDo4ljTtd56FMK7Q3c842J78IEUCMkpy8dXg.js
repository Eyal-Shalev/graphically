/* Source and licensing information for the line(s) below can be found at http://178.62.34.160/modules/statistics/statistics.js. */
(function($){$(document).ready(function(){$.ajax({type:"POST",cache:false,url:Drupal.settings.statistics.url,data:Drupal.settings.statistics.data})})})(jQuery);;
/* Source and licensing information for the above line(s) can be found at http://178.62.34.160/modules/statistics/statistics.js. */
;/*})'"*/
